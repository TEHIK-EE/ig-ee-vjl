# Home - VJL - Vähiandmete juhtimislaud v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://fhir.ee/vjl/ImplementationGuide/ee.fhir.vjl | *Version*:0.1.0 |
| Draft as of 2026-08-18 | *Computable Name*:EEVJL |

## NB!

Tegemist on mustandiga, mitte kasutada arendustes! This is a draft IG!

### Intro

Vähiandmete juhtimislaud Implementation Guide

#### Source code

This IG source code is available in [GitHub](https://github.com/TEHIK-EE/ig-ee-vjl).

### How to start

Building and deploying information is located in [GitHub](https://github.com/TEHIK-EE/ig-ee-vjl) project [README](https://github.com/TEHIK-EE/ig-ee-vjl/blob/main/README.md) file.

